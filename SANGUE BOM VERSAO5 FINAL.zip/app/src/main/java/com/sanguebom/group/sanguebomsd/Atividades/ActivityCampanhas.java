package com.sanguebom.group.sanguebomsd.Atividades;

import android.support.annotation.NonNull;
import android.os.Bundle;
import android.util.Log;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sanguebom.group.sanguebomsd.Models.Campanha;
import com.sanguebom.group.sanguebomsd.MainActivity;
import com.sanguebom.group.sanguebomsd.R;

public class ActivityCampanhas extends MainActivity {
    private DatabaseReference referencia = FirebaseDatabase.getInstance().getReference();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_campanhas);

        DatabaseReference campanhas = referencia.child("campanha");

        Campanha campanha = new Campanha();
        //usuario.setNome("Renato nogueira");
       // usuario.setEmail("renato@kijo.com");


     campanhas.addValueEventListener(new ValueEventListener() {
         @Override
         public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
             Log.i("FIREBASE", dataSnapshot.getValue().toString());
         }

         @Override
         public void onCancelled(@NonNull DatabaseError databaseError) {

         }
     });


        campanhas.child("007").setValue(campanha);
    }

}
