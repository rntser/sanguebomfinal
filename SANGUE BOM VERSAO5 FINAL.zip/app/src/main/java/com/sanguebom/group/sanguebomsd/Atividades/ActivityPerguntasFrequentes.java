package com.sanguebom.group.sanguebomsd.Atividades;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.sanguebom.group.sanguebomsd.R;

public class ActivityPerguntasFrequentes extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perguntas_frequentes);
    }
}
