package com.sanguebom.group.sanguebomsd.Atividades;

import android.app.Activity;
import android.os.Bundle;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.sanguebom.group.sanguebomsd.Models.Evento;
import com.sanguebom.group.sanguebomsd.R;

public class ActivityEventos extends Activity {
    private DatabaseReference referencia = FirebaseDatabase.getInstance().getReference();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventos);

        DatabaseReference eventos = referencia.child("evento");

        Evento evento = new Evento();
        //usuario.setNome("Renato nogueira");
        // usuario.setEmail("renato@kijo.com");




        eventos.child("008").setValue(evento);

    }
}
