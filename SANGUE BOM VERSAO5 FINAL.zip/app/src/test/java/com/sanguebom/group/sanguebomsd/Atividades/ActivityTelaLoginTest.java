package com.sanguebom.group.sanguebomsd.Atividades;

import org.junit.Test;

import static org.junit.Assert.*;

public class ActivityTelaLoginTest {

    @Test
    public void onCreate() {
    }
}