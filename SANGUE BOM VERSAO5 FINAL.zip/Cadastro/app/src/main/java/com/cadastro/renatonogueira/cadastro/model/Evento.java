package com.cadastro.renatonogueira.cadastro.model;

public class Evento {
    private long idEvento;
    private String Nome;
    private char Tema;
    private char Assunto;
    private Usuário usuarioLogado;

    public Evento() {
    }

    public long getIdEvento() {
        return idEvento;
    }

    public void setIdEvento(long idEvento) {
        this.idEvento = idEvento;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public char getTema() {
        return Tema;
    }

    public void setTema(char tema) {
        Tema = tema;
    }

    public char getAssunto() {
        return Assunto;
    }

    public void setAssunto(char assunto) {
        Assunto = assunto;
    }

    @Override
    public String toString() {
        return "Evento{" +
                "idEvento=" + idEvento +
                ", Nome=" + Nome +
                ", usuarioLogado=" + usuarioLogado.toString() +
                ", Tema=" + Tema +
                ", Assunto=" + Assunto +
                '}'
                ;
    }
}
