package com.cadastro.renatonogueira.cadastro.model;

public class Usuário {
    private long idUsuario;
    private String Nome;
    private char Senha;

    public Usuário() {
    }

    public long getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public char getSenha() {
        return Senha;
    }

    public void setSenha(char senha) {
        Senha = senha;
    }

    @Override
    public String toString() {
        return "Usuário{" +
                "idUsuario=" + idUsuario +
                ", Nome='" + Nome + '\'' +
                ", Senha=" + Senha +
                '}';
    }
}
