package com.cadastro.renatonogueira.cadastro.model;

public class Campanha {
    private long idCamapanha;
    private String Nome;
    private char Tema;
    private char Assunto;
    private Usuário usuarioLogado;

    public Campanha() {
    }

    public long getIdCamapanha() {
        return idCamapanha;
    }

    public void setIdCamapanha(long idCamapanha) {
        this.idCamapanha = idCamapanha;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public char getTema() {
        return Tema;
    }

    public void setTema(char tema) {
        Tema = tema;
    }

    public char getAssunto() {
        return Assunto;
    }

    public void setAssunto(char assunto) {
        Assunto = assunto;
    }

    public Usuário getUsuarioLogado() {
        return usuarioLogado;
    }

    public void setUsuarioLogado(Usuário usuarioLogado) {
        this.usuarioLogado = usuarioLogado;
    }

    @Override
    public String toString() {
        return "Campanha{" +
                "idCamapanha=" + idCamapanha +
                ", Nome='" + Nome + '\'' +
                ", Tema=" + Tema +
                ", Assunto=" + Assunto +
                ", usuarioLogado=" + usuarioLogado.toString() +
                '}';
    }
}

